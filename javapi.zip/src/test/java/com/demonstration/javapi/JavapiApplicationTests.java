package com.demonstration.javapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
